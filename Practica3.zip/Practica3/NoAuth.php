<html>
    <head>
        <title> No autenticado </title>
        <meta charset="UTF-8">
    </head>
    <body>    
        <BR><BR><BR>
    <CENTER>
        <h3>Autenticación incorrecta</h3> <BR>
        <A href= 'login.php'> Volver a login </A>
    </CENTER>
</body>
</html>